<?php
include("bd.php");
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
  header("Location: login.html");
  exit();
}
// Consultar el consumo total
$sql = 'SELECT SUM(agua) as consumo_total FROM historico_agua where Fecha_consumo=CURDATE()';
$sql1 = 'SELECT SUM(agua) as consumo_total FROM historico_agua';
$resultado = $conn->query($sql);
$resultado1 = $conn->query($sql1);
if ($resultado) {
    $fila = $resultado->fetch_assoc();
    $consumo_total = $fila['consumo_total'];
  } else {
    $consumo_total = 0;
  }
// Comprobar si la consulta devolvió resultados
if ($resultado1) {
  $fila1 = $resultado1->fetch_assoc();
  $consumo_total1 = $fila1['consumo_total'];
} else {
  $consumo_total1 = 0;
}

// Mostrar el resultado
echo 'Consumo total del dia: ' . $consumo_total."L <br>";
echo 'Consumo total: ' . $consumo_total1."L\n";
// Cerrar la conexión a la base de datos
$conn->close();
?>