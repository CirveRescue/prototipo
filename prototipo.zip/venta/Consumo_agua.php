<?php include("template/cabecera.php"); 
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
  header("Location: login.html");
  exit();
}
?>


<h1>CONSUMO DE AGUA</h1>
    <canvas width="100" height="1 00" id="miGrafica"></canvas>
    <div id="consumo-total"></div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <h1>CONSUMO DE ENERGIA</h1>
    <canvas width="100" height="1 00" id="miGrafica1"></canvas>
    <div id="consumo-total1"></div>

<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.3.2"></script>
<script>
// Autenticación mediante clave API
const apiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkZXYiOiJFU1AzMiIsImlhdCI6MTY4MjQ2MzUyMSwianRpIjoiNjQ0ODViMjFkNzQ5ZjYyZDk3MGY2NWRmIiwic3ZyIjoidXMtZWFzdC5hd3MudGhpbmdlci5pbyIsInVzciI6IklzYWlNYWRyaWdhbCJ9.r6RjLww9L7mVDC0UgiatlLabyjZoXgtY8P9TURtdl3g';
const authHeader = {'Authorization': 'Bearer ' + apiKey};



const miGrafica1 = document.getElementById('miGrafica1').getContext('2d');
const grafica1 = new Chart(miGrafica1, {
  type: 'bar',
  data: {
    labels: ['Consumo En Tiempo Real del flujo de Energia'],
    datasets: [{
      label: 'Consumo En Tiempo Real del flujo de Energia',
      data: [0],
      backgroundColor: [
        'rgba(56, 68, 170, 0.2)',
        'rgba(56, 68, 170, 0.2)'
      ],
      borderColor: [
        'rgba(56, 68, 170, 1)',
        'rgba(56, 68, 170, 1)'
      ],
      borderWidth: 1
    }]
  },
  options: {
    maintainAspectRatio: true,
    aspectRatio: 3,
    scales: {
      y: {
        beginAtZero: true
      }
    }
    }

});

const miGrafica = document.getElementById('miGrafica').getContext('2d');
const grafica = new Chart(miGrafica, {
  type: 'bar',
  data: {
    labels: ['Consumo En Tiempo Real del flujo de Agua'],
    datasets: [{
      label: 'Consumo En Tiempo Real del flujo de Agua',
      data: [0],
      backgroundColor: [
        'rgba(56, 68, 170, 0.2)',
        'rgba(56, 68, 170, 0.2)'
      ],
      borderColor: [
        'rgba(56, 68, 170, 1)',
        'rgba(56, 68, 170, 1)'
      ],
      borderWidth: 1
    }]
  },
  options: {
    maintainAspectRatio: true,
    aspectRatio: 3,
    scales: {
      y: {
        beginAtZero: true
      }
    }
    }

});
function actualizarDatos() {
  fetch('https://backend.thinger.io/v3/users/IsaiMadrigal/devices/ESP32/resources/datos', {
    method: 'POST',
    headers: authHeader
  })
  .then(response => response.json())
  .then(data => {
    
    // Obtener el valor de consumo y guardar en la base de datos
    const consumo = data['Consumo En Tiempo Real'];
    const consumo1 = data['Potencia '];
    
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'guardar_consumo.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
        console.log(xhr.responseText);
      }
    };
    xhr.send('&consumo=' + encodeURIComponent(consumo));

    const xhr1 = new XMLHttpRequest();
    xhr1.open('POST', 'guardar_consumo1.php', true);
    xhr1.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr1.onreadystatechange = function() {
      if (xhr1.readyState === 4 && xhr1.status === 200) {
        console.log(xhr1.responseText);
      }
    };
    xhr1.send('&consumo=' + encodeURIComponent(consumo1));
    // Actualizar la gráfica
    const potencia = [consumo];
    grafica.data.datasets[0].data[0] = potencia;
    grafica.update();

        // Actualizar la gráfica
    const potencia1 = [consumo1];
    grafica1.data.datasets[0].data[0] = potencia1;
    grafica1.update();


  })
  .catch(error => {
    console.error(error);
  });
  
}

function actualizarConsumoTotal() {
  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'mostrar_consumo.php', true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      const consumoTotalElement = document.getElementById('consumo-total');
      consumoTotalElement.innerHTML = xhr.responseText;
    }
  };
  xhr.send();
}
function actualizarConsumoTotal1() {
  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'mostrar_consumo1.php', true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      const consumoTotalElement = document.getElementById('consumo-total1');
      consumoTotalElement.innerHTML = xhr.responseText;
    }
  };
  xhr.send();
}
setInterval(actualizarConsumoTotal, 10000);
setInterval(actualizarConsumoTotal1, 10000);
actualizarConsumoTotal()
actualizarConsumoTotal1()
// Llamar la función actualizarDatos() cada segundo
setInterval(actualizarDatos, 7000);
actualizarDatos(); // Llamamos a la función para que actualice los datos la primera vez
</script>

<?php include("template/pie.php"); ?>