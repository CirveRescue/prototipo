<?php include ("template/cabecera.php"); 
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
  header("Location: login.html");
  exit();
}?>
<body>  
<marquee behavior="alternative" scrollamount=7 >
    <font face="Century Gothic" color="white" >
    Consumo MAAGGUI es una de las mejores aplicaciones con la mejor administracion sobre el consumo de energia y agua el cual nos ayudara a ver en tiempo real cuanto consumimos.
</font>
</marquee>
        <div class="jumbotron">
            <font color="white">
            <h1 class="display-3">Consumo MAAGGUI</h1>  
            <p class="lead">Consumo de agua y energia en el hogar, tramitiendo de forma inalambrica</p>
            <hr class="my-2">
            </div>
                    <img src="https://thumbs.dreamstime.com/z/plantilla-de-icono-logotipo-energ%C3%ADa-diluci%C3%B3n-agua-y-rel%C3%A1mpago-del-luz-la-s%C3%ADmbolo-vector-electricidad-ilustraci%C3%B3n-negocios-171577688.jpg" width="350" height="350">
                </div>


        </div> 
</body>
</font>
    </body>
<?php include ("template/pie.php"); ?>





