<?php

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proyecto1";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Error de conexión: " . $conn->connect_error);
}

// Obtener los datos enviados por el formulario de inicio de sesión
$username = $_POST['username'];
$password = $_POST['contrasena'];

// Consulta SQL para verificar las credenciales
$sql = "SELECT * FROM user WHERE id_usuario = '$username' AND contrasena = '$password'";
$result = $conn->query($sql);

session_start();

if ($result->num_rows > 0) {
  // Inicio de sesión exitoso, redireccionar a la página principal
  $_SESSION['username'] = $username; // Almacena el nombre de usuario en la sesión
  header("Location: index.php");
} else {
  // Credenciales inválidas, mostrar mensaje de error
  echo "Usuario o contraseña incorrectos";
}

$conn->close();
?>