<?php
ob_start();
include("template/cabecera.php");
include("bd.php");
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}
// Definir variables
$fechaInicio = '';
$fechaFin = '';
$result = null;

// Verificar si se envió una fecha para filtrar
if (isset($_POST['fecha_inicio']) && isset($_POST['fecha_fin'])) {
    // Obtener las fechas desde el formulario
    $fechaInicio = $_POST['fecha_inicio'];
    $fechaFin = $_POST['fecha_fin'];

    // Ejecutar consulta con filtro por rango de fechas
    $sql = "SELECT
      CASE WHEN row_number = 1 THEN agua and energia ELSE 0 END AS agua,
      Fecha_consumo,
      energia
    FROM (
      SELECT
        E.agua,
        E.Fecha_consumo,
        B.energia AS energia,
        ROW_NUMBER() OVER (PARTITION BY E.agua ORDER BY E.Fecha_consumo) AS row_number
      FROM historico_agua AS E
      JOIN historico_energia AS B ON E.Fecha_consumo = B.Fecha_consumo
      WHERE E.Fecha_consumo BETWEEN '$fechaInicio' AND '$fechaFin'
    ) AS subquery";

    // Ejecutar consulta
    $result = mysqli_query($conn, $sql);

    // Combinar resultados de ambas consultas
    $combinedResults = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $combinedResults[] = $row;
    }

    // Ordenar los resultados por Fecha_consumo en orden ascendente
    usort($combinedResults, function ($a, $b) {
        return strtotime($a['Fecha_consumo']) - strtotime($b['Fecha_consumo']);
    });

    // Asignar los resultados combinados a $result para mostrarlos en la tabla
    $result = $combinedResults;
}

// Mostrar el formulario de filtrado
echo '
    <form method="POST" class="filtro-form">
        <label for="fecha_inicio">Fecha inicio:</label>
        <input type="date" name="fecha_inicio" id="fecha_inicio" value="' . $fechaInicio . '">
        <label for="fecha_fin">Fecha fin:</label>
        <input type="date" name="fecha_fin" id="fecha_fin" value="' . $fechaFin . '">
        <button type="submit" id="filtrar" name="filtrar" value="filtrar">Filtrar</button>
        <button type="submit" id="action" name="action" value="descargar">Descargar</button>
    </form>
';

// Verificar si se encontraron resultados
if ($result && count($result) > 0) {
    // Imprimir los datos en una tabla HTML
    echo "<table>";
    echo "<tr><th>agua</th><th>energia</th><th>Fecha_consumo</th></tr>";
    foreach ($result as $row) {
        echo "<tr>";
        echo "<td>" . $row["agua"] . "L</td>";
        echo "<td>" . $row["energia"] . "A</td>";
        echo "<td>" . $row["Fecha_consumo"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Verificar el botón presionado
if (isset($_POST['action'])) {
    $action = $_POST['action'];

    // Generar archivo PDF y descargarlo
    if ($action == "descargar") {
        // Crear el objeto FPDF
        require('fpdf185/fpdf.php');
        $pdf = new FPDF();

        // Agregar una página
        $pdf->AddPage();

        // Establecer el título del documento
        $pdf->SetTitle('Reporte de Consumo');

        // Establecer el estilo de la fuente
        $pdf->SetFont('Arial', 'B', 12);

        // Establecer el contenido del PDF
        $pdf->Cell(0, 10, 'Reporte de Consumo', 0, 1, 'C');
        $pdf->Ln(10);

        // Imprimir los datos en una tabla en el PDF
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(30, 10, 'Agua', 1, 0, 'C');
        $pdf->Cell(30, 10, 'Energia', 1, 0, 'C');
        $pdf->Cell(40, 10, 'Fecha de Consumo', 1, 1, 'C');
        $pdf->SetFont('Arial', '', 10);
        foreach ($result as $row) {
            $pdf->Cell(30, 10, $row['agua'] . 'L', 1, 0, 'C');
            $pdf->Cell(30, 10, $row['energia'] . 'A', 1, 0, 'C');
            $pdf->Cell(40, 10, $row['Fecha_consumo'], 1, 1, 'C');
        }

        // Cerrar el objeto PDF y generar el archivo PDF
        ob_end_clean(); // Limpiar cualquier salida anterior
        $pdf->Output('reporte_consumo.pdf', 'D'); // Descargar el archivo PDF
    }
}


?>

<style>
.filtro-form {
    margin-bottom: 20px;
}

.filtro-form label {
    font-weight: bold;
}

.filtro-form input[type="date"] {
    padding: 5px;
}

.filtro-form button {
    padding: 5px 10px;
    background-color: #4CAF50;
    color: white;
    border: none;
    cursor: pointer;
}
/* Estilos para la tabla */
table {
    width: 100%;
    border-collapse: collapse;
}

table th,
table td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

/* Estilos para el formulario de filtrado */
.filtro-form {
    margin-bottom: 20px;
    display: flex;
    align-items: center;
}

.filtro-form label {
    font-weight: bold;
    margin-right: 10px;
}

.filtro-form input[type="date"],
.filtro-form button {
    padding: 5px 10px;
}

.filtro-form button {
    background-color: #4CAF50;
    color: white;
    border: none;
    cursor: pointer;
}

/* Estilos para el botón de descarga */
.filtro-form button[name="action"][value="descargar"] {
    background-color: #f44336;
    margin-left: 10px;
}

/* Estilos para mensajes de error */
.error-message {
    color: #f44336;
    margin-top: 10px;
}

/* Estilos generales */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 960px;
    margin: 0 auto;
    padding: 20px;
}

.page-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}

</style>