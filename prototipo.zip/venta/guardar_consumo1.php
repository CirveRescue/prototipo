<?php
include("bd.php");
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
  header("Location: login.html");
  exit();
}



$authHeader = array('Authorization: Bearer ' . 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkZXYiOiJFU1AzMiIsImlhdCI6MTY4MjQ2MzUyMSwianRpIjoiNjQ0ODViMjFkNzQ5ZjYyZDk3MGY2NWRmIiwic3ZyIjoidXMtZWFzdC5hd3MudGhpbmdlci5pbyIsInVzciI6IklzYWlNYWRyaWdhbCJ9.r6RjLww9L7mVDC0UgiatlLabyjZoXgtY8P9TURtdl3g'
);
$resourceUrl = 'https://backend.thinger.io/v3/users/IsaiMadrigal/devices/ESP32/resources/datos';
$response = file_get_contents($resourceUrl, false, stream_context_create(array(
  'http' => array(
    'method' => 'GET',
    'header' => implode("\r\n", $authHeader)
  )
)));

$data = json_decode($response, true);

// Insertar los datos en la tabla historico
if (isset($data['Potencia '])) {
  $agua = $data['Potencia '];

  if (!empty($agua)) {
    $sql = "INSERT INTO `historico_energia`(`energia`, `Fecha_consumo`) VALUES (?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("d",$agua);

    

    $stmt->execute();

    $stmt->close();
  }
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
