<?php include("template/cabecera.php"); 
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
  header("Location: login.html");
  exit();
}
?>


<h1>Gráfica</h1>
    <canvas width="100" height="1 00" id="miGrafica"></canvas>
    <div id="consumo-total"></div>
    

<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.3.2"></script>
<script>
// Autenticación mediante clave API
const apiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkZXYiOiJFU1AzMiIsImlhdCI6MTY4MjQ2MzUyMSwianRpIjoiNjQ0ODViMjFkNzQ5ZjYyZDk3MGY2NWRmIiwic3ZyIjoidXMtZWFzdC5hd3MudGhpbmdlci5pbyIsInVzciI6IklzYWlNYWRyaWdhbCJ9.r6RjLww9L7mVDC0UgiatlLabyjZoXgtY8P9TURtdl3g';
const authHeader = {'Authorization': 'Bearer ' + apiKey};




const miGrafica = document.getElementById('miGrafica').getContext('2d');
const grafica = new Chart(miGrafica, {
  type: 'bar',
  data: {
    labels: ['Consumo En Tiempo Real del flujo de Energia'],
    datasets: [{
      label: 'Consumo En Tiempo Real del flujo de Energia',
      data: [0],
      backgroundColor: [
        'rgba(56, 68, 170, 0.2)',
        'rgba(56, 68, 170, 0.2)'
      ],
      borderColor: [
        'rgba(56, 68, 170, 1)',
        'rgba(56, 68, 170, 1)'
      ],
      borderWidth: 1
    }]
  },
  options: {
    maintainAspectRatio: true,
    aspectRatio: 3,
    scales: {
      y: {
        beginAtZero: true
      }
    }
    }

});
function actualizarDatos() {
  fetch('https://backend.thinger.io/v3/users/IsaiMadrigal/devices/ESP32/resources/datos', {
    method: 'GET',
    headers: authHeader
  })

    // Actualizar la gráfica
    const potencia = [consumo1];
    grafica.data.datasets[0].data[0] = potencia;
    grafica.update();


}

function actualizarConsumoTotal() {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', 'mostrar_consumo1.php', true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      const consumoTotalElement = document.getElementById('consumo-total');
      consumoTotalElement.innerHTML = xhr.responseText;
    }
  };
  xhr.send();
}

setInterval(actualizarConsumoTotal, 1000);
actualizarConsumoTotal()
// Llamar la función actualizarDatos() cada segundo
setInterval(actualizarDatos, 1000);
actualizarDatos(); // Llamamos a la función para que actualice los datos la primera vez
</script>

<?php include("template/pie.php"); ?>
